package com.chaitanya.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import ablelogin.MainActivity;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void Login(View v)
    {
        EditText username = (EditText)findViewById(R.id.txt_username);
        EditText passwd = (EditText) findViewById(R.id.txt_password);
        TextView errorText = (TextView)findViewById(R.id.txt_error);
        String usrnme = username.getText().toString();
        String password = passwd.getText().toString();

        boolean validationFlag = false;
        if(!usrnme.isEmpty() && !password.isEmpty())
        {
            if(usrnme.equals("admin") && password.equals("admin")) {
                validationFlag = true;
            }
        }
        if(!validationFlag)
        {
            errorText.setVisibility(View.VISIBLE);
        }
        else
        {
            Intent redirect = new Intent(login.this, MainActivity.class);
            startActivity(redirect);
        }
    }
}
